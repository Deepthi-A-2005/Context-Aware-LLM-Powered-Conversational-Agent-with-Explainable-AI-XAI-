/**
 * NeuralContext XAI — Shared JavaScript
 * Handles: dark mode, sidebar, active nav state, canvas charts
 */

/* ─── Dark Mode ─────────────────────────────────────────── */
(function initTheme() {
  const stored = localStorage.getItem('nc-theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const isDark = stored === 'dark' || (!stored && prefersDark);
  if (isDark) document.documentElement.classList.add('dark');
})();

function toggleTheme() {
  const isDark = document.documentElement.classList.toggle('dark');
  localStorage.setItem('nc-theme', isDark ? 'dark' : 'light');
  document.querySelectorAll('.theme-toggle').forEach(btn => {
    btn.setAttribute('aria-label', isDark ? 'Switch to light mode' : 'Switch to dark mode');
    btn.querySelector('.theme-icon').textContent = isDark ? 'light_mode' : 'dark_mode';
  });
}

/* ─── Sidebar Mobile Toggle ─────────────────────────────── */
function toggleSidebar() {
  document.querySelector('.sidebar')?.classList.toggle('open');
}

/* ─── Active Nav Link ────────────────────────────────────── */
function setActiveNav() {
  const current = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('[data-navlink]').forEach(el => {
    const href = el.getAttribute('href') || '';
    if (href.endsWith(current)) {
      el.classList.add('active');
    }
  });
}

/* ─── Canvas Chart Utilities ─────────────────────────────── */
function getCSSVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

/**
 * Draw a smooth line chart on a canvas element.
 * @param {HTMLCanvasElement} canvas
 * @param {object} opts
 */
function drawLineChart(canvas, opts) {
  const { datasets, labels, yMin = 0, yMax = 100, title } = opts;
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const W = canvas.offsetWidth;
  const H = canvas.offsetHeight;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  ctx.scale(dpr, dpr);

  const padL = 44, padR = 16, padT = 24, padB = 36;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;

  const secondary = getCSSVar('--color-secondary');
  const outline = getCSSVar('--color-outline-variant');
  const textColor = getCSSVar('--color-on-surface-variant');

  // Grid lines
  ctx.strokeStyle = outline;
  ctx.lineWidth = 0.5;
  ctx.setLineDash([4, 4]);
  for (let i = 0; i <= 4; i++) {
    const y = padT + (plotH / 4) * i;
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(padL + plotW, y); ctx.stroke();
    const val = yMax - (i / 4) * (yMax - yMin);
    ctx.fillStyle = textColor;
    ctx.font = `10px JetBrains Mono, monospace`;
    ctx.textAlign = 'right';
    ctx.fillText(val.toFixed(0), padL - 6, y + 4);
  }
  ctx.setLineDash([]);

  // X labels
  if (labels) {
    ctx.fillStyle = textColor;
    ctx.font = `10px JetBrains Mono, monospace`;
    ctx.textAlign = 'center';
    labels.forEach((lbl, i) => {
      const x = padL + (i / (labels.length - 1)) * plotW;
      ctx.fillText(lbl, x, H - padB + 16);
    });
  }

  // Datasets
  datasets.forEach((ds, di) => {
    const colors = ['#00677e', '#00d2fd', '#ba7f00', '#49607e'];
    const color = ds.color || colors[di % colors.length];
    const pts = ds.data.map((v, i) => ({
      x: padL + (i / (ds.data.length - 1)) * plotW,
      y: padT + plotH - ((v - yMin) / (yMax - yMin)) * plotH
    }));

    // Fill gradient
    const grad = ctx.createLinearGradient(0, padT, 0, padT + plotH);
    grad.addColorStop(0, color + '33');
    grad.addColorStop(1, color + '00');
    ctx.beginPath();
    pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.lineTo(pts[pts.length-1].x, padT + plotH);
    ctx.lineTo(pts[0].x, padT + plotH);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.stroke();

    // Dots
    pts.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
      ctx.strokeStyle = getCSSVar('--color-surface-container-lowest');
      ctx.lineWidth = 2;
      ctx.stroke();
    });

    // Legend label
    if (ds.label) {
      ctx.fillStyle = color;
      ctx.font = `600 10px JetBrains Mono, monospace`;
      ctx.textAlign = 'left';
      ctx.fillText(`■ ${ds.label}`, padL + di * 120, padT - 8);
    }
  });
}

/**
 * Draw a horizontal bar chart.
 */
function drawBarChart(canvas, opts) {
  const { data, labels, color, yLabel } = opts;
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const W = canvas.offsetWidth;
  const H = canvas.offsetHeight;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  ctx.scale(dpr, dpr);

  const padL = 48, padR = 16, padT = 16, padB = 40;
  const plotW = W - padL - padR;
  const plotH = H - padT - padB;
  const maxVal = Math.max(...data) * 1.1;

  const outline = getCSSVar('--color-outline-variant');
  const textColor = getCSSVar('--color-on-surface-variant');
  const barColor = color || getCSSVar('--color-secondary');

  // Grid
  ctx.strokeStyle = outline;
  ctx.lineWidth = 0.5;
  ctx.setLineDash([4, 4]);
  for (let i = 0; i <= 4; i++) {
    const y = padT + (plotH / 4) * i;
    ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
    const val = maxVal * (1 - i / 4);
    ctx.fillStyle = textColor;
    ctx.font = `10px JetBrains Mono, monospace`;
    ctx.textAlign = 'right';
    ctx.fillText(val.toFixed(0), padL - 6, y + 4);
  }
  ctx.setLineDash([]);

  const barW = (plotW / data.length) * 0.6;
  const gap = (plotW / data.length) * 0.4;

  data.forEach((val, i) => {
    const x = padL + i * (plotW / data.length) + gap / 2;
    const barH = (val / maxVal) * plotH;
    const y = padT + plotH - barH;

    const grad = ctx.createLinearGradient(x, y, x, padT + plotH);
    grad.addColorStop(0, barColor + 'ee');
    grad.addColorStop(1, barColor + '88');

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.roundRect(x, y, barW, barH, [3, 3, 0, 0]);
    ctx.fill();

    // Label
    ctx.fillStyle = textColor;
    ctx.font = `10px JetBrains Mono, monospace`;
    ctx.textAlign = 'center';
    ctx.fillText(labels[i], x + barW / 2, H - padB + 16);

    // Value
    ctx.fillStyle = barColor;
    ctx.font = `600 11px JetBrains Mono, monospace`;
    ctx.fillText(val, x + barW / 2, y - 4);
  });
}

/**
 * Draw a donut/gauge chart.
 */
function drawDonut(canvas, opts) {
  const { value, max = 100, color, label, sublabel } = opts;
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const W = canvas.offsetWidth;
  const H = canvas.offsetHeight;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  ctx.scale(dpr, dpr);

  const cx = W / 2, cy = H / 2;
  const r = Math.min(W, H) * 0.38;
  const thickness = r * 0.22;
  const pct = value / max;
  const startAngle = -Math.PI / 2;
  const endAngle = startAngle + pct * 2 * Math.PI;

  const outline = getCSSVar('--color-outline-variant');
  const chartColor = color || getCSSVar('--color-secondary');
  const textPrimary = getCSSVar('--color-on-surface');

  // Background arc
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, 2 * Math.PI);
  ctx.strokeStyle = outline;
  ctx.lineWidth = thickness;
  ctx.stroke();

  // Value arc
  const grad = ctx.createLinearGradient(cx - r, cy, cx + r, cy);
  grad.addColorStop(0, chartColor);
  grad.addColorStop(1, getCSSVar('--color-accent-vivid') || '#00d2fd');

  ctx.beginPath();
  ctx.arc(cx, cy, r, startAngle, endAngle);
  ctx.strokeStyle = grad;
  ctx.lineWidth = thickness;
  ctx.lineCap = 'round';
  ctx.stroke();

  // Center text
  ctx.fillStyle = textPrimary;
  ctx.font = `800 ${r * 0.55}px Inter, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(value, cx, cy - 6);

  if (label) {
    ctx.font = `600 ${r * 0.18}px JetBrains Mono, monospace`;
    ctx.fillStyle = getCSSVar('--color-on-surface-variant');
    ctx.fillText(label, cx, cy + r * 0.32);
  }
}

/* ─── Attention Heatmap ──────────────────────────────────── */
function buildAttentionHeatmap(container, tokens, weights) {
  container.innerHTML = '';
  const n = tokens.length;
  const grid = document.createElement('div');
  grid.style.display = 'grid';
  grid.style.gridTemplateColumns = `repeat(${n + 1}, auto)`;
  grid.style.gap = '2px';
  grid.style.fontSize = '11px';
  grid.style.fontFamily = 'JetBrains Mono, monospace';

  // Header row
  const corner = document.createElement('div');
  grid.appendChild(corner);
  tokens.forEach(t => {
    const el = document.createElement('div');
    el.textContent = t;
    el.style.cssText = 'padding:4px 6px;color:var(--color-on-surface-variant);text-align:center;writing-mode:vertical-rl;transform:rotate(180deg);font-size:10px;';
    grid.appendChild(el);
  });

  weights.forEach((row, i) => {
    const label = document.createElement('div');
    label.textContent = tokens[i];
    label.style.cssText = 'padding:4px 6px;color:var(--color-on-surface-variant);white-space:nowrap;font-size:10px;display:flex;align-items:center;';
    grid.appendChild(label);

    row.forEach(w => {
      const cell = document.createElement('div');
      const alpha = Math.round(w * 220);
      cell.style.cssText = `width:28px;height:28px;border-radius:4px;background:rgba(0,103,126,${w.toFixed(2)});cursor:pointer;transition:transform 0.1s;`;
      cell.title = `Weight: ${w.toFixed(3)}`;
      cell.addEventListener('mouseenter', () => { cell.style.transform = 'scale(1.15)'; });
      cell.addEventListener('mouseleave', () => { cell.style.transform = 'scale(1)'; });
      grid.appendChild(cell);
    });
  });

  container.appendChild(grid);
}

/* ─── Animate Numbers ────────────────────────────────────── */
function animateNumber(el, target, duration = 800, decimals = 0) {
  const start = performance.now();
  const from = parseFloat(el.textContent) || 0;
  function step(now) {
    const progress = Math.min((now - start) / duration, 1);
    const ease = 1 - Math.pow(1 - progress, 3);
    const current = from + (target - from) * ease;
    el.textContent = decimals > 0 ? current.toFixed(decimals) : Math.round(current).toString();
    if (progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

/* ─── Intersection Observer for Chart Init ───────────────── */
function observeCharts() {
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const initFn = window[el.dataset.chartInit];
        if (initFn) { initFn(el); io.unobserve(el); }
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('[data-chart-init]').forEach(el => io.observe(el));
}

/* ─── Copy Code Block ────────────────────────────────────── */
function copyCode(btn) {
  const block = btn.closest('.code-block');
  const code = block.querySelector('pre, code');
  if (!code) return;
  navigator.clipboard.writeText(code.textContent).then(() => {
    const orig = btn.textContent;
    btn.textContent = 'check';
    setTimeout(() => { btn.textContent = orig; }, 1500);
  });
}

/* ─── Toast Notification ─────────────────────────────────── */
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  const colors = { info: '#00677e', success: '#16a34a', warning: '#d97706', error: '#dc2626' };
  toast.style.cssText = `
    position:fixed;bottom:24px;right:24px;z-index:9999;
    padding:12px 20px;border-radius:8px;
    background:var(--color-surface-container-lowest);
    border:1px solid var(--color-outline-variant);
    box-shadow:var(--shadow-elevated);
    font-family:JetBrains Mono,monospace;font-size:13px;
    color:var(--color-on-surface);
    border-left:3px solid ${colors[type] || colors.info};
    transform:translateY(80px);opacity:0;
    transition:all 0.25s cubic-bezier(0.4,0,0.2,1);
  `;
  toast.textContent = message;
  document.body.appendChild(toast);
  requestAnimationFrame(() => {
    toast.style.transform = 'translateY(0)';
    toast.style.opacity = '1';
  });
  setTimeout(() => {
    toast.style.transform = 'translateY(80px)';
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

/* ─── Init on DOM Ready ──────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  setActiveNav();
  observeCharts();

  // Update theme toggle icon on load
  const isDark = document.documentElement.classList.contains('dark');
  document.querySelectorAll('.theme-toggle .theme-icon').forEach(el => {
    el.textContent = isDark ? 'light_mode' : 'dark_mode';
  });

  // Animate metrics on load
  document.querySelectorAll('[data-animate-to]').forEach(el => {
    const target = parseFloat(el.dataset.animateTo);
    const decimals = parseInt(el.dataset.decimals || '0');
    animateNumber(el, target, 1000, decimals);
  });
});

// Re-render charts on theme change
const themeObserver = new MutationObserver(() => {
  document.querySelectorAll('[data-chart-init]').forEach(el => {
    const fn = window[el.dataset.chartInit];
    if (fn) fn(el);
  });
});
themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
